package proj.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/SearchData")
public class SearchData extends HttpServlet
{
		protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
		
		{
			response.setContentType("text/html");
			PrintWriter out=response.getWriter();
			
		
			String from=request.getParameter("from");
			String to=request.getParameter("to");
			String departdate=request.getParameter("departdate");
			String arrivedate=request.getParameter("arrivedate");
			String classs=request.getParameter("classs");
			String adult=request.getParameter("adult");
			String child=request.getParameter("child");
			
			
			String flightNameId=request.getParameter("flightNameId");
			String departtime=request.getParameter("departtime");
			String arrivetime=request.getParameter("arrivetime");
			String duration=request.getParameter("duration");
			String price=request.getParameter("price");
		//	System.out.println(from+" "+to+" "+departdate+" "+arrivedate+" "+classs+" "+adult+" "+child);
		//	System.out.print(flightNameId+" "+from+" "+to+" "+arrivedate+" "+arrivetime+" "+duration+" "+price);

			try
			{
				
				Class.forName("com.mysql.jdbc.Driver");
				Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/javaprobd","root","");
				PreparedStatement ps=con.prepareStatement("select * from `flightdetail` where `from`=? and `to`=? or `departtime`=? or `arrivetime`=? ");
				ps.setString(1,from);
				ps.setString(2, to);
				ps.setString(3,departtime);
				ps.setString(4, arrivetime);
				

				ResultSet rs=ps.executeQuery();
				while(rs.next())
				{
	System.out.println(rs.getString("flightNameId")+" "+rs.getString("from")+" "+rs.getString("to")+" "+rs.getString("departtime")+" "+rs.getString("arrivetime")+" "+rs.getString("duration")+" "+rs.getString("price"));
				
				}
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
				
			
			
			
		}

	}
