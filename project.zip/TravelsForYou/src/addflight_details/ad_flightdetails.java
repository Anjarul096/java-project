package addflight_details;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/admin/ad_flightdetails")
public class ad_flightdetails extends HttpServlet {
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
			response.setContentType("text/html");
			PrintWriter out=response.getWriter();
			
			String flightNameId=request.getParameter("flightNameId");
			String from=request.getParameter("from");
			String to=request.getParameter("to");
			String departtime=request.getParameter("departtime");
			String arrivetime=request.getParameter("arrivetime");
			String duration=request.getParameter("duration");
			String price=request.getParameter("price");
			String availabledays=request.getParameter("availabledays");
			String classs=request.getParameter("classs");
			String distance=request.getParameter("distance");
			
			System.out.print(flightNameId+" "+from+" "+to+" "+departtime+" "+arrivetime+" "+duration+" "+price+" "+availabledays+" "+classs+" "+distance);
		
		try
		{
				Class.forName("com.mysql.jdbc.Driver");
				Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/javaprobd","root","");
				PreparedStatement ps=con.prepareStatement("insert into flightdetail values(?,?,?,?,?,?,?,?,?,?)");
				ps.setString(1,flightNameId);
				ps.setString(2,from);
				ps.setString(3,to);
				ps.setString(4,departtime);
				ps.setString(5,arrivetime);
				ps.setString(6,duration);
				ps.setString(7,price);
				ps.setString(8,availabledays);
				ps.setString(9,classs);
				ps.setString(10,distance);
			
		int x=ps.executeUpdate();
				if(x>0)
				{
					response.sendRedirect("dashboard.jsp");
				}
				else
				{
					out.print("unsucessfull register of FLIGHT DETAILS");	
				}
			
			
		}
		catch(Exception e)
				{
					e.printStackTrace();
					
				}
		
	}

}
