package updateFLIGHTDETAILS;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/admin/updateFLIGHTDETAILS")
public class updateFLIGHTDETAILS extends HttpServlet {
	private static final long serialVersionUID = 1L;
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		
		
		System.out.println("calllllled");
		String from=request.getParameter("from");
		String to=request.getParameter("to");
		String departtime=request.getParameter("departtime");
		String arrivetime=request.getParameter("arrivetime");
		String duration=request.getParameter("duration");
		String price=request.getParameter("price");
		String availabledays=request.getParameter("availabledays");
		String classs=request.getParameter("classs");
		String distance=request.getParameter("distance");
		String flightNameId=request.getParameter("flightNameId");
		try
		{
			Class.forName("com.mysql.jdbc.Driver");
	        Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/javaprobd","root","");
			PreparedStatement ps=con.prepareStatement("update `flightdetail` set `from`=?,`to`=?,`departtime`=?,`arrivetime`=?,`duration`=?,`price`=?,`availabledays`=?,`classs`=?,`distance`=? where `flightNameId`=?");
			
				ps.setString(1, from);
				ps.setString(2, to);
				ps.setString(3, departtime);
				ps.setString(4, arrivetime);
				ps.setString(5, duration);
				ps.setString(6, price);
				ps.setString(7, availabledays);
				ps.setString(8, classs);
				ps.setString(9, distance);
				ps.setString(10, flightNameId);
			
			int x=ps.executeUpdate();
			if(x>0)
			{
				response.sendRedirect("dashboard.jsp?msg='Successfully Updated'");
				//System.out.print(flightNameId+" "+from+" "+to+" "+departtime+" "+arrivetime+" "+duration+" "+price+" "+availabledays+" "+classs+""+distance);
			}	
			else
			{
				response.sendRedirect("dashboard.jsp?msg='FLIGHT DETAILS UPDATE CAN'T DONE'");
				//System.out.println("FLIGHT DETAILS UPDATE CAN'T DONE");
			
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}

	}

}
