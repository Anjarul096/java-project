package userlog;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import database.GetConnection;


@WebServlet("/user/userup")
public class userup extends HttpServlet {
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		String name=request.getParameter("name");
		String phoneno=request.getParameter("phoneno");
		String email=request.getParameter("email");
		String password=request.getParameter("password");
		try {
            Connection con=GetConnection.GetCon();
            
            
            PreparedStatement ps=con.prepareStatement("insert into user_control values(?,?,?,?)");
			ps.setString(3,name);
			ps.setString(4,phoneno);
			ps.setString(1,email);
			ps.setString(2,password);
			int x=ps.executeUpdate();
			if(x>0)
			{
				response.sendRedirect("../index.jsp?msg='Login Successfull'");
				
			}
			else
			{
				response.sendRedirect("../error.jsp");
			}
			
		    } 
		catch (Exception e) 
		   {
            
			e.printStackTrace();
			
		   }
	
	
	
	}

}
