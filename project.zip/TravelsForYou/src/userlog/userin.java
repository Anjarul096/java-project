package userlog;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import database.GetConnection;

@WebServlet("/user/userin")
public class userin extends HttpServlet {
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		String emailid=request.getParameter("emailid");
		String password=request.getParameter("password");
		
		
		//System.out.print(email+"  "+password);
		
      
		try {
	         
	         Connection con=GetConnection.GetCon();
	         PreparedStatement ps=con.prepareStatement("select * from user_control where emailid=? and password=?");
	         
	         ps.setString(1, emailid);
	         ps.setString(2, password);
	         ResultSet rs=ps.executeQuery();
	         if(rs.next())
	         {
	        	 HttpSession hs=request.getSession();
	        	 ArrayList<String> al=new ArrayList<String>();
	        	 al.add(rs.getString(1));
	        	 al.add(rs.getString(2));
	        	 al.add(rs.getString(3));
	        	 al.add(rs.getString(4));
	        	 hs.setAttribute("user", al);
	        	 
	        	 String flightid =(String)hs.getAttribute("flightid");
	        	 if(flightid==null)
	        	 {
	        		 response.sendRedirect("../index.jsp?msg='Login Successfull'");
	        	 }
	        	 else
	        	 {
	        		 response.sendRedirect("../booknow.jsp?msg='Login Sucessfull'");
	        	 }
	         }
	         else
	         {
	        	 response.sendRedirect("../error.jsp?msg='incorrect email/password'");
	         }	    } 
		catch (Exception e)
             { 
			
			    e.printStackTrace();
		     }
	}

		
		
		
	}


